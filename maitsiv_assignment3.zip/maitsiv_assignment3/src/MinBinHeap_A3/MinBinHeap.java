package MinBinHeap_A3;

public class MinBinHeap implements Heap_Interface {
  private EntryPair[] array; //load this array
  private int size;
  private static final int arraySize = 10000; //Everything in the array will initially 
                                              //be null. This is ok! Just build out 
                                              //from array[1]

  public MinBinHeap() {
    this.array = new EntryPair[arraySize];
    array[0] = new EntryPair(null, -100000); //0th will be unused for simplicity 
                                             //of child/parent computations...
                                             //the book/animation page both do this.
  }
    
  //Please do not remove or modify this method! Used to test your entire Heap.
  @Override
  public EntryPair[] getHeap() { 
    return this.array;
  }

@Override
public void insert(EntryPair entry) {
	if (entry == null) {
		return;
	}
	if (entry.priority >= 0) {	
		if (array[1] == null) {
			array[1] = entry;
		} else {
			array[size + 1] = entry;
		}
		size++;
		bubbleUp(entry, size);	
	}	
	
}

@Override
public void delMin() {
	if (size == 0) {
		return;
	}
	if (size == 1) {
		array[1] = null;
		size--;
		return;
	} else {
		array[1] = null;
		array[1] = array[size];
		array[size] = null;
		bubbleDown(1);
		size--;
	}
	
}

@Override
public EntryPair getMin() {
	if (size == 0) {
		return null;
	}
	return array[1];
}

@Override
public int size() {	
	return size;
	
}

@Override
public void build(EntryPair[] entries) {
	if (entries == null) {
		return;
	}
	for (int i = 0; i < entries.length; i++) {
		if (entries[i] != null) {
			if (entries[i].priority >= 0) {
				array[size + 1] = entries[i];
				size++;
				}
		}		
	}
	
	for (int i = 0; i < size; i++) {
		int lastParent = Math.floorDiv(size - i -1, 2);
		bubbleDown(lastParent);
	}
}

public void bubbleUp(EntryPair ep, int size) {
	int parentIndex = Math.floorDiv(size,  2);
	if (ep.priority < array[parentIndex].priority) {
		EntryPair temp = ep;
		array[size] = array[parentIndex];
		array[parentIndex] = temp;
		bubbleUp(array[parentIndex], parentIndex);
	}
}

public void bubbleDown(int index) {
	int childIndex = index * 2;
	if (array[childIndex] == null && array[childIndex + 1] == null) {
		return;
	}
	else if (array[childIndex] == null) {
		childIndex++;
	} else if (array[childIndex + 1] != null) {		
		if (array[childIndex].priority > array[childIndex + 1].priority) {
			childIndex++;
		}
	}
	if (array[index].priority > array[childIndex].priority) {
		//System.out.println("hello");
				EntryPair temp = array[index];
				array[index] = array[childIndex];
				array[childIndex] = temp;
				bubbleDown(childIndex);
	}		
	
	
}
}